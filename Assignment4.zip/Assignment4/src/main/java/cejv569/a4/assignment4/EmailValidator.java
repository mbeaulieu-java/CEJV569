package cejv569.a4.assignment4;

/**
 * EmailValidator is a simple static utility class with a function that validates the format of emails.  Theoretically, this class and it's
 * method could be used elsewhere in the application or even by another, to avoid code duplication
 * when validating email format.  Currently, it is used by the login form and the contact form, in this app.
 */
public class EmailValidator {
    private EmailValidator(){}

    //Regex String used to validate if the email follows the general format required of an email.
    //I don't use the RFC 5322 standard, https://emailregex.com/.  Just a very loose regular expression based
    //validation.


    public final static String EMAIL_REGEX =
                     "^([\\w+ " +  "\\W N+]" + "{" + "1" + ",}" +
                    "@{" + "1" + "}" +
                    "[\\w+]{" + "1" + ",}" +
                     "\\.{" + "1" + "}" +
                    "[\\w+]{" + "1" + ",})";

    /**
     *  validateEmail() validates that the email format follow certain formatting rules such as using only certain
     *  character and not others, containing an @ followed by a domain name of the format .*.
     * @param email, String type - is the email address to be validated
     * @return - boolean type, returns true if the email matches the regex expression format and false if it
     * doesn't.
     */
    public static boolean validateEmail(String email){
        return email.matches(EMAIL_REGEX);
    }
}
