package cejv569.a4.assignment4;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;

import java.net.URL;
import java.util.ResourceBundle;

/**
 *  The ContactController class directs the functionality of the contactForm.  It thus validates the
 *  information input by the user into the contact fields and provides feedback messages to the user concerning
 *  the input data.
 */
public class ContactController {
    /**
     * User Message Constants
     */
    private final String SUBMIT_MESSAGE = "Your message has been sent. You should receive a response " +
                                            " in the next 24 hours. ";
    private final String NAME_BLANK_MESSAGE = "The Name field cannot be left blank.";

    private final String INVALID_EMAIL_MESSAGE = "Invalid email address. The value must not" +
            " be empty and must contain the following symbols: \' @ . \'";

    /**
     * Resource Paths constants
     */
    //relative path for the submit button graphic
    private final String SUBMIT_IMAGE_PATH = "assets/submit.png";


    private String name;
    private String email;
    private String message;
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField nameTextField;

    @FXML
    private TextField emailTextField;

    @FXML
    private TextArea messageTextArea;

    @FXML
    private Button submitButton;

    /**
     *  initialize() sets the background graphic for the submit button and adds an event handler for it.
     */
    @FXML
    void initialize() {
        Image submitImage = new Image(getClass()
                .getResource(SUBMIT_IMAGE_PATH)
                .toExternalForm());

        BackgroundImage submitBckImage = new BackgroundImage(submitImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
                new BackgroundSize(BackgroundSize.AUTO,BackgroundSize.AUTO, false,
                        false, true, false));
        submitButton.setBackground(new Background(submitBckImage));
        submitButton.addEventHandler(ActionEvent.ACTION,(e)->{validateContactInfo();});
    }

    /**
     * Setters and Getters for class attributes
     */
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    /**
     *  setEmailField is called from the profileForm when the user clicks Contact Us in the main menu.  It sets
     *  the email textfield to the user's email, which was obtained at login as the user parameter.  This was to save
     *  the user from having to enter the email again, though the user has the option of changing it in the contact form.
     * @param email
     */
    public void setEmailField(String email){
        emailTextField.setText(email);
    }

    /**
     * validateContactInfo validates to make sure the user entered their name (not leaving it blank) and
     * email (not leaving it blank) in a proper email format.  If the information was not entered correctly,
     * then the user is given a warning via a dialog window.  If all the info is correct, the contact info is
     * stored in the class attributes and a dialog informs the user that their request will be submitted
     * and a response obtaioned shortly.
     */
    private void validateContactInfo() {
        if (!validateName()) {
            Alert invalidNameAlert = new Alert(Alert.AlertType.ERROR,NAME_BLANK_MESSAGE);
            invalidNameAlert.show();
            nameTextField.requestFocus();;
        } else if (!validateEmail()) {
            Alert alert = new Alert(Alert.AlertType.ERROR,INVALID_EMAIL_MESSAGE);
            alert.show();
            emailTextField.requestFocus();
        } else {
            processContactDetails();
            displaySubmitMessage();
        }

    }

    /**
     * validateName() validates that the user enters their name prior to submitting their message by checking
     * if the field is left blank.
     * @return - boolean tyoe, returns true if the name field is not empty and false if it is.
     */
    private boolean validateName() {
        return !nameTextField.getText().trim().equals("");
    }

    /**
     *  validateEmail() firsts validates to make sure the email field was not left blank, after which
     *  it uses the EmailValidator utility class to validate the format of the email to make sure it follows
     *  the usual email format.
     * @return - boolean type, returns true if the email is valid and false if it is not
     */
    private boolean validateEmail() {
        String email = emailTextField.getText().trim();
        return !email.equals("") && EmailValidator.validateEmail(email);
    }

    /**
     *  processContactDetails() sets the name, email and message attributes of the class for possible future
     *  use (future assignments).
     */
    private void processContactDetails() {
        setName(nameTextField.getText());
        setEmail(emailTextField.getText());
        setMessage(messageTextArea.getText());
    }

    /**
     *  displaySubmitMessage() simply displays a message to the user that their email was submitted and
     *  will be treated within a certain given delay of time.
     */
    private void displaySubmitMessage() {
        Alert submitAlert = new Alert(Alert.AlertType.INFORMATION);
        submitAlert.setContentText(SUBMIT_MESSAGE);
        submitAlert.show();
    }
}
