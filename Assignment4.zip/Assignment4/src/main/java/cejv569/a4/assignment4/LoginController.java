package cejv569.a4.assignment4;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.IOException;


/**
 *  LoginController controls all the validation and functionality of the loginForm.  It's main purpose is
 *  to validate the user and password of the user and, if these are correct, to open the profileForm.  The
 *  controller also opens the contactForm is the user clicks on the Contact Us button.
 */
public class LoginController {
    /**
     * User Message Constants
     */
   private final String INVALID_PASSWORD_MESSAGE = "Invalid password.  The password " +
           "should be at least 8 characters long.";

    private final String INVALID_EMAIL_MESSAGE = "Invalid email address. The value must not" +
            " be empty and must contain the following symbols: \' @ . \'";

    /**
     * Resource Paths constants
     */
    //relative path for the submit button graphic
    private final String LOGIN_IMAGE_PATH = "assets/login.png";

    @FXML
    private Button loginButton;

    @FXML
    private Button contactButton;


    @FXML
    private PasswordField passwordTextField;

    @FXML
    private TextField userTextField;

    /**
     *  initialize() firsts sets the background graphic for the login button.  After which it assigns an
     *  event handler to the loginButton which calls the method which validates the user and password.  It also
     *  assigns an event handler to the contactButton to open the contactForm if clicked.
     */
    @FXML
    void initialize() {
        Image loginImage = new Image(getClass()
                .getResource(LOGIN_IMAGE_PATH)
                .toExternalForm());

        BackgroundImage loginBckImage = new BackgroundImage(loginImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
                new BackgroundSize(BackgroundSize.AUTO,BackgroundSize.AUTO, false,
                        false, true, false));
        loginButton.setBackground(new Background(loginBckImage));
        loginButton.addEventHandler(ActionEvent.ACTION,(e)->{validateLogin();});
        contactButton.addEventHandler(ActionEvent.ACTION,(e)->{getContactPane();});
    }

    /**
     * validateUser() validates the user value entered, which is the user's email address.  Thus it firsts makes
     * sure the user field is not blank and then uses the static utility class EmailValidator to verify that
     * the user parameter (email) has the proper format of an email.
     * @return boolean type - returns true of the user field is not blank and the value entered  is formatted
     *                          as an email should be.
     */
    private boolean validateUser() {
        String user = userTextField.getText().trim();
        return !user.equals("") && EmailValidator.validateEmail(user);

    }

    /**
     * validatePassword() validates that the user entered a password, the field is not blank, and also that the
     * password is at least 8 characters in length.  No other rules are applied.
     * @return - boolean type, returns true if the password is not blank and at least 8 characters in length and
     *                          false if it is blank or invalid.
     */
    private boolean validatePassword() {
        String password = passwordTextField.getText().trim();
        return (password.length() >= 8);
    }

    /**
     * validateLogin() validates both the user and password field values.  If these are both valid, it opens the
     * profileForm.  If the user is invalid, it will display an error dialog to inform the user of the error.
     * If an invalid password is entered, this too causes a error dialog to be displayed.
     * For now, there is no specific validation of the user and password against an existing entry in a
     * database.
     */
    public void validateLogin(){
        if (validateUser()) {
            if(validatePassword()) {
                try {
                    FXMLLoader fxmlLoader = new FXMLLoader(Application.class.getResource("profileForm.fxml"));
                    Scene scene = new Scene(fxmlLoader.load());
                    Stage stage = new Stage();
                    stage.setScene(scene);
                    stage.centerOnScreen();
                    contactButton.getScene().getWindow().hide();
                    ((ProfileController)fxmlLoader.getController()).setEmail(userTextField.getText());
                    stage.show();
                } catch(IOException | IllegalStateException e ){
                    System.err.println(e.getMessage());
                }
            }else {
                    Alert alert = new Alert(Alert.AlertType.ERROR,INVALID_PASSWORD_MESSAGE);
                    alert.show();
                    passwordTextField.requestFocus();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR,INVALID_EMAIL_MESSAGE);
            alert.show();
            userTextField.requestFocus();
        }
    }

    /**
     *  getContactPane() displays the contactForm if the user clicks the Contact Us button.
     */
    public void getContactPane(){

        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Application.class.getResource("contactForm.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.centerOnScreen();
            //commented out for now, as it would seem to make more sense to come back to the login screen
            //after letting the user contact the company.  The user could then choose to login.
            //contactButton.getScene().getWindow().hide();
            stage.showAndWait();
        } catch(IOException | IllegalStateException e ){
            System.err.println(e.getMessage());
        }
    }

}