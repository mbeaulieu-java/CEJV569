module cejv569.a4.assignment4 {
    requires javafx.controls;
    requires javafx.fxml;

    opens cejv569.a4.assignment4 to javafx.fxml;
    exports cejv569.a4.assignment4;
}