module cejv569.a3.assignment3 {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires org.kordamp.ikonli.javafx;
    requires org.kordamp.bootstrapfx.core;

    opens cejv569.a3.assignment3 to javafx.fxml;
    exports cejv569.a3.assignment3;
}