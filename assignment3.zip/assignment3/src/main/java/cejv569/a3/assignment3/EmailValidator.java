package cejv569.a3.assignment3;

/**
 *
 */
public class EmailValidator {
    private EmailValidator(){}

    //Regex String used to validate if the email follows the general format required of an email
    public final static String EMAIL_REGEX = "^([\\w\\+" +  "\\W N\\+]" + "[^\\ / % + = ? < > { } \'" + "\"]{"
            + "1" + ",}@{" + "1" + "}[\\w+ -]{" + "1" + ",}.{" + "1" + ",}[\\w+]{1,})";

    /**
     *
     * @param email
     * @return
     */
    public static Boolean validateEmail(String email){
        return email.matches(EMAIL_REGEX);
    }
}
