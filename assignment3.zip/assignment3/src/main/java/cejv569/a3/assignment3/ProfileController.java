package cejv569.a3.assignment3;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;

/**
 *
 */
public class ProfileController {

    @FXML
    private Label emailLabel;

    @FXML
    private Label contactLabel;

    /**
     *
     */
    @FXML
    void initialize() {
        contactLabel.addEventHandler(MouseEvent.MOUSE_CLICKED,(e)->{
            getContactPane();
        });
    }

    /**
     *
     * @param aEmail
     */
    public void setEmail(String aEmail){
        if (emailLabel != null) {
            emailLabel.setText(aEmail);
        }
    }

    /**
     *
     */
    private void getContactPane() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Application.class.getResource("contactForm.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            Stage stage = new Stage();
            scene.setUserData(emailLabel.getText());;
            stage.setScene(scene);
            stage.centerOnScreen();
            ((ContactController)fxmlLoader.getController()).setEmailField(emailLabel.getText());
            stage.showAndWait();
        } catch(IOException | IllegalStateException e ){
            System.err.println(e.getMessage());
        }
    }

}
