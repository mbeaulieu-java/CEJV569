package cejv569.a3.assignment3;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.IOException;


/**
 *
 */
public class LoginController {

    @FXML
    private Button loginButton;

    @FXML
    private Button contactButton;


    @FXML
    private PasswordField passwordTextField;

    @FXML
    private TextField userTextField;

    /**
     *
     */
    @FXML
    void initialize() {
        Image loginImage = new Image(getClass()
                .getResource("assets/login.png")
                .toExternalForm());

        BackgroundImage loginBckImage = new BackgroundImage(loginImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
                new BackgroundSize(BackgroundSize.AUTO,BackgroundSize.AUTO, false,
                        false, true, false));
        loginButton.setBackground(new Background(loginBckImage));
        loginButton.addEventHandler(ActionEvent.ACTION,(e)->{validateLogin(e);});
        contactButton.addEventHandler(ActionEvent.ACTION,(e)->{getContactPane();});
    }

    /**
     *
     * @return
     */
    private boolean validateUser() {
        String user = userTextField.getText().trim();
        return !user.equals("") && EmailValidator.validateEmail(user);

    }

    /**
     *
     * @return
     */
    private boolean validatePassword() {
        String password = passwordTextField.getText().trim();
        return (!password.equals("") && password.length() >= 8);
    }

    /**
     *
     * @param event
     */
    public void validateLogin(ActionEvent event){
        if (validateUser()) {
            if(validatePassword()) {
                try {
                    FXMLLoader fxmlLoader = new FXMLLoader(Application.class.getResource("profileForm.fxml"));
                    Scene scene = new Scene(fxmlLoader.load());
                    Stage stage = new Stage();
                    stage.setScene(scene);
                    stage.centerOnScreen();
                    contactButton.getScene().getWindow().hide();
                    ((ProfileController)fxmlLoader.getController()).setEmail(userTextField.getText());
                    stage.show();
                } catch(IOException | IllegalStateException e ){
                    System.err.println(e.getMessage());
                }
            }else {
                    Alert alert = new Alert(Alert.AlertType.ERROR,"Invalid password.  The password " +
                            "should be at least 8 characters long.");
                    alert.show();
                    passwordTextField.requestFocus();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR,"Invalid email address. The value must not" +
                    " be empty and must contain the following symbols: \' @ . \'");
            alert.show();
            userTextField.requestFocus();
        }
    }

    /**
     *
     */
    public void getContactPane(){

        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Application.class.getResource("contactForm.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.centerOnScreen();
            //commented out for now, as it would seem to make more sense to come back to the login screen
            //after letting the user contact the company.  The user could then choose to login.
            //contactButton.getScene().getWindow().hide();
            stage.showAndWait();
        } catch(IOException | IllegalStateException e ){
            System.err.println(e.getMessage());
        }
    }

}