package cejv569.a3.assignment3;

import javafx.event.ActionEvent;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {

    @FXML
    private Button loginButton;

    @FXML
    private Button contactButton;


    @FXML
    private PasswordField passwordTextField;

    @FXML
    private TextField userTextField;


    @FXML
    void initialize() {
        Image loginImage = new Image(getClass()
                .getResource("assets/login.png")
                .toExternalForm());

        BackgroundImage loginBckImage = new BackgroundImage(loginImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
                new BackgroundSize(BackgroundSize.AUTO,BackgroundSize.AUTO, false,
                        false, true, false));
        loginButton.setBackground(new Background(loginBckImage));
        loginButton.addEventHandler(ActionEvent.ACTION,(e)->{validateLogin(e);});
        contactButton.addEventHandler(ActionEvent.ACTION,(e)->{getContactPane();});
    }

    private boolean validateUser() {
        String user = userTextField.getText();
        return (!user.equals("") && user.contains("@") && user.contains("."));
    }

    private boolean validatePassword() {
        String password = passwordTextField.getText();
        return (!password.equals("") && password.length() >= 8);
    }

    public void validateLogin(ActionEvent event){
        if (validateUser()) {
            if(validatePassword()) {
                //do login
            }else {
                    Alert alert = new Alert(Alert.AlertType.ERROR,"Invalid password.  The password " +
                            "should be at least 8 characters long.");
                    alert.show();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR,"Invalid email address. The value must not" +
                    " be empty and must contain the following symbols: \' @ . \'");
            alert.show();
        }
    }
    public void getContactPane(){
        ContactController contactController = new ContactController();
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Application.class.getResource("contactForm.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.centerOnScreen();
            contactButton.getScene().getWindow().hide();
            stage.show();
        } catch(IOException | IllegalStateException e ){
            System.err.println(e.getMessage());
        }

    }

}