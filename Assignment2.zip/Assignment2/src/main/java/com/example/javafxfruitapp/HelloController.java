package com.example.javafxfruitapp;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class HelloController {
    //this does nothing for now
}