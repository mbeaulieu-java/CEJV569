package com.example.javafxfruitapp;

/**
 *
 * Assignment 2:
 *
 * This application creates a main FlowPane, labels and 4 checkboxes.  Each of the checkboxes represent
 * a fruit choice that a user can select.
 *
 * Upon selection/checking or unchecking of a checkbox two events occur:
 *      If the checkbox is checked:
 *          A) The fruit it represents appears in the selected label.
 *          B) An effect is applied to the text attribute of the checkbox.
 *      If the checkbox is unchecked:
 *              A) The fruit it represents is removed from the text appearing in the selected label.
 *              B) Any effect applied to the checkbox text attribute is removed.
 *
 *      The following effects are applied:
 *          bananaCheckBox = text is blurred via a Gaussian Blur effect
 *          mangoCheckBox = text is doubled in size via a Scale effect
 *          grapesCheckBox = text is rotated a number of degrees using a Rotate effect
 *          orangeCheckBox = text is reflected via a Reflection effect

 */

import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.effect.Reflection;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.application.Application;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.text.FontWeight;
import javafx.scene.transform.Rotate;
import javafx.scene.transform.Scale;
import javafx.stage.Stage;
import java.io.IOException;


public class HelloApplication extends Application implements EventHandler{
    //Effect objects
    private GaussianBlur checkboxBlur;
    private Scale checkboxScale;
    private Rotate checkboxRotate;
    private Reflection checkboxReflect;

    //Root Pane and Components
    private FlowPane rootFlowPane;
    private VBox chksVbox;
    private Label title;
    private Label selected;
    private CheckBox bananaCheckBox;
    private CheckBox mangoCheckBox;
    private CheckBox grapesCheckBox;
    private CheckBox orangeCheckBox;

    //global string used to initialize the text attribute for the selected Label.
    private String fruits;

    /**
     * The start method creates the main FlowPane root and it's associated components
     * which are then displayed.
     * @param stage
     * @throws IOException
     */
    @Override
    public void start(Stage stage) throws IOException {
        final Double gapProportion = 0.15;
        //set the forms title
        stage.setTitle("Assignment 2 - Transformations and text effects");

        //create a new label and call setTitle to set the label parameters
        title = setTitle(new Label("Transformations and Effects"));

        //set the parameters for the label which displays the fruit options that are selected via the
        //CheckBoxes
        selected = new Label("");
        selected.setWrapText(true);
        selected.maxWidth(5.0);

        //call setCheckBoxPanel to create all the checkboxes and add them to a vbox panel
        setCheckBoxPanel();

        // set the parameters for the main FlowPane (rootFlowPane)
         setRootPaneParams();

        // add all the components and the panel containing the checkboxes to the root pane
        rootFlowPane.getChildren().addAll(title,chksVbox,
                 selected);

        // set the eventListeners for all the checkboxes
        setCheckBoxListeners();

        //create effects objects for the checkboxes
        createEffects();

        //create the scene, add it to the stage and show the window.
        Scene scene = new Scene(rootFlowPane, 400, 400);
        stage.setScene(scene);
        stage.show();

        // get the height of the vbox panel/container which contains all the checkboxes and use it to
        //space the checkboxes evenly vertically in the checkbox panel.
        chksVbox.setSpacing(chksVbox.getHeight() * gapProportion);
    }

    /**
     * createEffects calls the methods which creates and initializes each different effect to be applied
     * to a component.  In this case, the effects are applied to the checkboxes.
     */
    private void createEffects() {
        checkboxBlur = createGaussianBlurEffect();
        checkboxScale = createScaleTransform();
        checkboxReflect = createReflectEffect();
        checkboxRotate = createRotateTransform();
    }

    /**
     *  This sets all the events for each checkbox.  The first being the fruit selection appearing
     *  in the selected label text attribute and the second is an effect applied to the text attribute
     *  of the checkbox.
     */
    private void setCheckBoxListeners() {
        /*
         convert the vbox panel list of checkboxes to a stream to loop through the list to add an event
         to the OnActionListener.  This sets the ActionListener to call the functional interface method
         handle() since our HelloApplication class implements the EventHandler interface and overrides
         its handle function.  The handle() method in this case can act as a sort of global event
         handler for any components on the root pane, though it is only used for the checkboxes.*/
        chksVbox.getChildren().stream().forEach((c)->{((CheckBox)c).setOnAction(this);});

        //add an event handler so that selection or de-selection of a checkbox applies a
        // different effect to each checkbox or removes it.
        bananaCheckBox.addEventHandler(ActionEvent.ACTION,(e)-> onCheckBlurText(e));
        mangoCheckBox.addEventHandler(ActionEvent.ACTION,(e)-> onCheckScaleText(e));
        grapesCheckBox.addEventHandler(ActionEvent.ACTION,(e)-> onCheckRotateText(e));
        orangeCheckBox.addEventHandler(ActionEvent.ACTION,(e)-> onCheckReflectText(e));
    }

    /**
     *
     */
    private void setCheckBoxPanel() {

        bananaCheckBox = new CheckBox("Banana");
        mangoCheckBox = new CheckBox("Mango");
        grapesCheckBox = new CheckBox("Grapes");
        orangeCheckBox = new CheckBox("Orange");

        chksVbox = new VBox(bananaCheckBox, mangoCheckBox,grapesCheckBox, orangeCheckBox);
        chksVbox.setBorder(new Border(new BorderStroke(Color.BLACK,
                BorderStrokeStyle.SOLID,
                CornerRadii.EMPTY,new BorderWidths(1))));
        chksVbox.setAlignment(Pos.CENTER_LEFT);
        chksVbox.setMinSize(250,250);
        chksVbox.setPadding(new Insets(10,10,10,10));
    }

    /**
     *
     */
    private void setRootPaneParams() {
        rootFlowPane = new FlowPane(Orientation.VERTICAL, 5, 30);
        rootFlowPane.setMaxSize(500,500);
        rootFlowPane.setAlignment(Pos.CENTER);
        rootFlowPane.setPadding(new Insets(1,1,1,1));
    }

    /**
     *
     * @param aLabel
     * @return
     */
    private Label setTitle(Label aLabel){
        aLabel.setAlignment(Pos.TOP_CENTER);
        aLabel.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        aLabel.setUnderline(true);
        aLabel.setTextFill(Color.NAVY);
        return aLabel;
    }

    /**
     *
     */
    public void showAll() {
        fruits = "";
        if (bananaCheckBox.isSelected()){ fruits += " Banana";}
        if (mangoCheckBox.isSelected()) {fruits += " Mango";}
        if (grapesCheckBox.isSelected()) {fruits += " Grapes";}
        if (orangeCheckBox.isSelected()) {fruits += " Orange";}

        selected.setText("Fruits selected:" + fruits);
    }

    /**
     *
     * @param event
     */
    @Override
    public void handle(Event event) {
        //display in the selected label the fruits that are selected according to which checkboxes
        //has a status of selected = true.
        // This is updated every time a checkbox is checked or unchecked.
        showAll();
    }

    /**
     *
     * @return
     */
    public GaussianBlur createGaussianBlurEffect(){
        return new GaussianBlur(10);
    }

    /**
     *
     * @return
     */
    public Scale createScaleTransform() {
        Scale scale = new Scale();
        scale.setX(2);
        scale.setY(2);
        return scale;
    }

    /**
     *
     * @return
     */
    public Rotate createRotateTransform () {
        Rotate rotate = new Rotate();
        rotate.setAngle(25);
        rotate.setPivotX(0);
        rotate.setPivotY(0);
        return rotate;
    }

    /**
     *
     * @return
     */
    public Reflection createReflectEffect(){
        Reflection reflection = new Reflection();
        reflection.setTopOffset(0);
        reflection.setTopOpacity(0.75);
        reflection.setBottomOpacity(0.1);
        reflection.setFraction(1);
        return reflection;
    }

    /**
     *
     * @param event
     */
    public void onCheckBlurText(ActionEvent event) {

        if (event.getSource() instanceof CheckBox) {
           CheckBox chk = (CheckBox) event.getSource();
           if (chk.isSelected()) {
                chk.setEffect(checkboxBlur);
           } else {
               chk.setEffect(null);
           }
        }
    }

    /**
     *
     * @param event
     */
    public void onCheckScaleText(ActionEvent event) {
        if (event.getSource() instanceof CheckBox) {
            CheckBox chk = (CheckBox) event.getSource();
            if (chk.isSelected()) {
                chk.getTransforms().add(checkboxScale);
            } else {
                chk.getTransforms().remove(checkboxScale);
            }
        }
    }

    /**
     *
     * @param event
     */
    public void onCheckRotateText(ActionEvent event) {
        if (event.getSource() instanceof CheckBox) {
            CheckBox chk = (CheckBox) event.getSource();
            if (chk.isSelected()) {
                chk.getTransforms().add(checkboxRotate);
            } else {
                chk.getTransforms().remove(checkboxRotate);
            }
        }
    }

    /**
     *
     * @param event
     */
    public void onCheckReflectText(ActionEvent event) {
        if (event.getSource() instanceof CheckBox) {
            CheckBox chk = (CheckBox) event.getSource();
            if (chk.isSelected()) {
                chk.setEffect(checkboxReflect);
            } else {
                chk.setEffect(null);
            }
        }
    }


    public static void main(String[] args) {
        launch();
    }


}