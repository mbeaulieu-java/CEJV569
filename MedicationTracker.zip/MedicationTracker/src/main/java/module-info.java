module cejv569.medicationtracker {
    requires javafx.controls;
    requires javafx.fxml;

    opens cejv569.medicationtracker.controllers to javafx.fxml;
    exports cejv569.medicationtracker.controllers;

    //opens cejv569.medicationtracker.database to javafx.fxml;
    //exports cejv569.medicationtracker.database;

    //opens cejv569.medicationtracker.model to javafx.fxml;
    //exports cejv569.medicationtracker.model;

    opens cejv569.medicationtracker.utility to javafx.fxml;
    exports cejv569.medicationtracker.utility;

    opens cejv569.medicationtracker to javafx.fxml;
    exports cejv569.medicationtracker;
}