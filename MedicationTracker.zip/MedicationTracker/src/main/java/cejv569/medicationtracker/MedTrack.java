package cejv569.medicationtracker;

import cejv569.medicationtracker.utility.GUIUtility;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

/**
 *  The purpose of Assignment 3 is to practice using controllers classes and to design and manipulate
 *  multiple forms.  The concept of the app, in a very general way, is an app that theoretically would allow
 *  users to use graphic design tools and others products of the Melanos DesignI.T company.
 *
 *  The architecture of this app is a user login form which allows the user to login to access
 *  their profile.  The user can also choose to send an email to the company via the Contact Us button on the
 *  login form and also via the Contact Us "link" in the profile form menu.  In the Contact form the user
 *  can fill in their name, email and message and hit submit.  The user receives a message that their email
 *  has been sent.  The profile form is where the user can see their profile information and access various
 *  things about their account.
 */
public class MedTrack extends Application {

    private final String LOGIN_FILE_PATH = "loginForm.fxml";
    /**
     * Start() displays the login form.
     * @param stage, Stage type argument which is the main form of the application
     * @throws IOException
     */
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MedTrack.class.getResource(this.LOGIN_FILE_PATH));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("MedTrack");
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}