package cejv569.medicationtracker.utility;

public class UserMessages {

    public enum ErrorMessages {

        INVALID_PASSWORD_MESSAGE("Invalid password. " +
                "The password should be at least 8 characters long."),
        INVALID_EMAIL_MESSAGE("Invalid email address. The value must not" +
                " be empty and must contain the following symbols: \' @ . \'"),
        BLANK_ERROR_MESSAGE("Field cannot be blank."),
        PASSWORD_NOMATCH_ERROR("The password does not match the password confirmation value.");

        ErrorMessages(String msg) {
            this.message = msg;
        }

        public String message;
    }

        public enum Messages {

            SUBMIT_MESSAGE("Your message has been sent. You should receive a response " +
                    " in the next 24 hours. "),
            SUBMIT_TITLE ("Message Submitted"),
            SAVED_MESSAGE("The information has been saved."),
            SAVED_TITLE ("Information Saved");

            Messages(String msg) {this.message = msg;}
            public String message;
        }
}
