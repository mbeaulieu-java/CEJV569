package cejv569.medicationtracker.utility;


import cejv569.medicationtracker.MedTrack;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.io.IOException;

public class GUIUtility {

    private GUIUtility() {}

    public static void openPane(Stage aStage,String filePath) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MedTrack.class.getResource(filePath));
        Scene scene = new Scene(fxmlLoader.load());
        aStage.setTitle("MedTrack");
        aStage.setScene(scene);
        aStage.centerOnScreen();
        aStage.showAndWait();
    }

    public static void setButtonBackgroundImage(Class aClass,Button button, String imagePath) {
        Image image = new Image(aClass
                .getResource(imagePath)
                .toExternalForm());

        BackgroundImage bckImage = new BackgroundImage(image, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
                new BackgroundSize(BackgroundSize.AUTO,BackgroundSize.AUTO, false,
                        false, true, false));
        button.setBackground(new Background(bckImage));
    }


}
