package cejv569.medicationtracker.controllers;

import cejv569.medicationtracker.utility.UserMessages;
import cejv569.medicationtracker.utility.Validator;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;

/**
 *  The ContactController class directs the functionality of the contactForm.  It thus validates the
 *  information input by the user into the contact fields and provides feedback messages to the user concerning
 *  the input data.
 */
public class ContactController {

    /**
     * Resource Paths constants
     */
    //relative path for the submit button graphic
    private final String SUBMIT_IMAGE_PATH = "/cejv569/medicationtracker/assets/submit.png";


    private String name;
    private String email;
    private String message;

    @FXML
    private TextField nameTextField;

    @FXML
    private TextField emailTextField;

    @FXML
    private TextArea messageTextArea;

    @FXML
    private Button submitButton;

    @FXML
    private Label messageLabel;

    /**
     *  initialize() sets the background graphic for the submit button and adds an event handler for it.
     */
    @FXML
    void initialize() {

            Image submitImage = new Image(getClass()
                    .getResource(SUBMIT_IMAGE_PATH)
                    .toExternalForm());


        BackgroundImage submitBckImage = new BackgroundImage(submitImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
                new BackgroundSize(BackgroundSize.AUTO,BackgroundSize.AUTO, false,
                        false, true, false));
        submitButton.setBackground(new Background(submitBckImage));
        submitButton.addEventHandler(ActionEvent.ACTION,(e)->{validateContactInfo();});
    }

    /**
     * Setters and Getters for class attributes
     */
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    /**
     *  setEmailField is called from the profileForm when the user clicks Contact Us in the main menu.  It sets
     *  the email textfield to the user's email, which was obtained at login as the user parameter.  This was to save
     *  the user from having to enter the email again, though the user has the option of changing it in the contact form.
     * @param email
     */
    public void setEmailField(String email){
        emailTextField.setText(email);
    }

    /**
     * validateContactInfo validates to make sure the user entered their name (not leaving it blank) and
     * email (not leaving it blank and in a proper email format).  The Validator class method fieldBlankError
     * is used to check the name field is not blank and the Validator method isValidEmail is used to validate the
     * email.  fieldBlankError displays an error message if a field is left blank.
     * If the email is not correct then an error message is displayed.
     * If all the info is correct, the contact info is
     * stored in the class attributes and a dialog informs the user that their request will be submitted
     * and a response obtained shortly.
     */
    private void validateContactInfo() {

        if (nameTextField.equals("")) {
           Validator.displayFieldError(nameTextField,messageLabel,
                   UserMessages.ErrorMessages.BLANK_ERROR_MESSAGE.message);
        } else if (!Validator.isValidEmail(emailTextField.getText())) {
            Validator.displayFieldError(emailTextField,messageLabel,
                    UserMessages.ErrorMessages.INVALID_EMAIL_MESSAGE.message);
        } else {
            processContactDetails();
            displaySubmitMessage();
        }

    }

    /**
     *  processContactDetails() sets the name, email and message attributes of the class for possible future
     *  use (future assignments).
     */
    private void processContactDetails() {
        setName(nameTextField.getText());
        setEmail(emailTextField.getText());
        setMessage(messageTextArea.getText());
    }

    /**
     *  displaySubmitMessage() simply displays a message to the user that their email was submitted and
     *  will be treated within a certain given delay of time.
     */
    private void displaySubmitMessage() {

    }
}
