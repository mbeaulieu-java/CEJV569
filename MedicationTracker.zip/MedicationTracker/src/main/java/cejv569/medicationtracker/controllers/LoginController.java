package cejv569.medicationtracker.controllers;

import cejv569.medicationtracker.MedTrack;
import cejv569.medicationtracker.utility.GUIUtility;
import cejv569.medicationtracker.utility.UserMessages;
import cejv569.medicationtracker.utility.Validator;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.IOException;


/**
 *  LoginController controls all the validation and functionality of the loginForm.  It's main purpose is
 *  to validate the user and password of the user and, if these are correct, to open the profileForm.  The
 *  controller also opens the contactForm is the user clicks on the Contact Us button. Finally,
 *  if the user does not have user created, the user can sign up using the signup button (button displaying
 *  signup.png graphic) to display the signupForm.
 */
public class LoginController {


    /**
     * Resource Paths constants
     */
    //relative path for the button graphics
    private final String LOGIN_IMAGE_PATH = "/cejv569/medicationtracker/assets/login.png";
    private final String SIGNUP_IMAGE_PATH = "/cejv569/medicationtracker/assets/signup.png";
    private final String CONTACT_IMAGE_PATH = "/cejv569/medicationtracker/assets/contact.png";

    /**
     * Constants for FXML files
     */

    private final String CONTACT_FILE_PATH = "contactForm.fxml";
    private final String PROFILE_FILE_PATH = "profileForm.fxml";
    private final String SIGNUP_FILE_PATH = "signupForm.fxml";



    @FXML
    private Button loginButton;

    @FXML
    private Button contactButton;

    @FXML
    private Button signupButton;

    @FXML
    private PasswordField passwordTextField;

    @FXML
    private TextField userTextField;

    @FXML
    private Label messageLabel;

    /**
     *  initialize() firsts sets the background graphic for the login and signup buttons.
     *  After which it assigns event handlers to all the buttons.
     */
    @FXML
    void initialize() {

      //create the background image and set the background for the loginButton
//
        GUIUtility.setButtonBackgroundImage(getClass(),loginButton,LOGIN_IMAGE_PATH);

        //create the background image and set the background for the signupButton
        GUIUtility.setButtonBackgroundImage(getClass(),signupButton,SIGNUP_IMAGE_PATH);

        //create the background image and set the background for the ContactButton
        GUIUtility.setButtonBackgroundImage(getClass(),contactButton,CONTACT_IMAGE_PATH);

        // Add event handlers for buttons
        loginButton.addEventHandler(ActionEvent.ACTION,(e)->{validateLogin();});
        contactButton.addEventHandler(ActionEvent.ACTION,(e)->{getContactPane();});
        signupButton.addEventHandler(ActionEvent.ACTION,(e)->{getSignUpPane();});
    }

    /**
     * validateLogin() validates both the user and password field values.  If these are both valid, it opens the
     * profileForm.  If the user is invalid, it will display an error dialog to inform the user of the error.
     * If an invalid password is entered, this too causes a error dialog to be displayed.
     * For now, there is no specific validation of the user and password against an existing entry in a
     * database.
     */
    public void validateLogin(){

        if (Validator.isValidUser(userTextField.getText())) {
            if(Validator.isValidPassword(passwordTextField.getText())) {
                messageLabel.setVisible(false);
                try {
                    Stage stage = new Stage();
                    GUIUtility.openPane(stage,PROFILE_FILE_PATH);
//                    ((ProfileController)fxmlLoader.getController()).setEmail(userTextField.getText());
                } catch(IOException | IllegalStateException e ){
                    System.err.println(e.getMessage());
                }
            }else {
                    Validator.displayFieldError(passwordTextField,messageLabel,
                            UserMessages.ErrorMessages.INVALID_PASSWORD_MESSAGE.message);
            }
        } else {
            Validator.displayFieldError(userTextField,messageLabel,
                    UserMessages.ErrorMessages.INVALID_EMAIL_MESSAGE.message);
        }
    }

    /**
     *  getContactPane() displays the contactForm.fxml if the user clicks the contactButton button.
     */
    public void getContactPane(){

        try {
            Stage stage = new Stage();
            GUIUtility.openPane(stage,CONTACT_FILE_PATH);
        } catch(IOException | IllegalStateException e ){
            System.err.println(e.getMessage());
        }
    }

    /**
     *  getSignUpPane() displays the signupForm.fxml if the user clicks the signupButton button.
     */
    public void getSignUpPane(){

        try {
            Stage stage = new Stage();
            GUIUtility.openPane(stage,SIGNUP_FILE_PATH);
        } catch(IOException | IllegalStateException e ){
            System.err.println(e.getMessage());
        }
    }

}