package cejv569.medicationtracker.controllers;


import cejv569.medicationtracker.MedTrack;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;

/**
 *   ProfileController is the controller class which controls the functionality of the profileForm.
 *   If the user selects Contact Us from the side main menu of the profileForm, the controller opens
 *   the contactForm.
 */
public class ProfileController {

    @FXML
    private Label emailLabel;

    @FXML
    private Label contactLabel;

    /**
     *  initialize() adds an eventhandler to the contactLabel so that the contactForm is displayed if the user
     *  clicks the contactLabel with their mouse.
     */
    @FXML
    void initialize() {
        contactLabel.addEventHandler(MouseEvent.MOUSE_CLICKED,(e)->{
            getContactPane();
        });
    }

    /**
     *  setEmail() is called from the user loginForm to set the emailLabel to the user email entered as a
     *  user name in the loginForm, since the user's email is used as a user name.
     * @param aEmail - String type - is the user name/ email address of the user, obtained from the loginForm.
     */
    public void setEmail(String aEmail){
        if (emailLabel != null) {
            emailLabel.setText(aEmail);
        }
    }

    /**
     * getContactPane() displays the contactForm, upon the user clicking the Contact Us label.  It also gets
     * the email from the emailLabel field and pre-populates the email field of the contactForm to save the user
     * some time entering it, if it's the same email they want to receive the response to their email at.
     */
    private void getContactPane() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(MedTrack.class.getResource("contactForm.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.centerOnScreen();
            ((ContactController)fxmlLoader.getController()).setEmailField(emailLabel.getText());
            stage.showAndWait();
        } catch(IOException | IllegalStateException e ){
            System.err.println(e.getMessage());
        }
    }
}
