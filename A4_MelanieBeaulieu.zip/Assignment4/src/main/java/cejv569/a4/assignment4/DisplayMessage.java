package cejv569.a4.assignment4;

import javafx.scene.control.Alert;

/**
 * The displayMessage class is a static class used to display Information type messages and also contains the constants
 * for the messages.  It serves as a centralized utility class for messages to be displayed by the app.
 */

public class DisplayMessage {

    //Message Constants

    public static final String SUBMIT_MESSAGE = "Your message has been sent. You should receive a response " +
            " in the next 24 hours. ";
    public static final String SUBMIT_TITLE = "Message Submitted";

    public static final String SAVED_MESSAGE = "The information has been saved.";
    public static final String SAVED_TITLE = "Information Saved";

    private DisplayMessage() {}

    /**
     * displayInformationMessage() displays an alert of type Information, setting the alert title and header
     * to the value of the argument title and the content to the value of the message argument.
     * @param title - String type, the title and header message to use for the the alert
     * @param message - String type, the message content to be displayed by the alert.
     */
    public static void displayInformationalMessage(String title,String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(title);
        alert.setContentText(message);
        alert.show();
    }

}


