package cejv569.a4.assignment4;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;

/**
 *  The SignupController class takes care of initialization tasks for the controls of the signupForm.fxml file.
 *  It also performs all validation of the information that is required to be filled in the text fields of the
 *  form.
 */

public class SignupController {

        @FXML
        private VBox signupVBox;

        @FXML
        private TextField firstNameTextField;

        @FXML
        private TextField lastNameTextField;

        @FXML
        private TextField userTextField;

        @FXML
        private PasswordField passwordTextField;

        @FXML
        private PasswordField confirmPasswordTextField;

        @FXML
        private Button saveButton;

    /**
     * initialize() adds an event handler to the saveButton that validates all the text fields in the
     * form and if they are all filled correctly calls save() save to save the information.
     */
    @FXML
        void initialize() {

            saveButton.addEventHandler(ActionEvent.ACTION,e-> {
                if (fieldsValid()) {save();}});
        }

    /**
     * fieldsValid validates each field to make sure that it isn't blank, that the user name is entered
     * as an email with the proper format and also that the password is at least 8 characters long and
     * that the password confirmation matches the password entered in the prior field.  If a field has an
     * invalid value, false is immediately returned after displaying an error message and setting the focus
     * to the field with the invalid value.  This way, each field is tested one at a time.
     * @return boolean type, returns true if all the form fields are valid and false if
     *                      at least one field is not.
     */
    private boolean fieldsValid() {
            //validate to make sure the First Name Field is not Blank
            if (isFieldEmpty(firstNameTextField)){return false;}

            //validate to make sure the Last Name Field is not Blank
            if (isFieldEmpty(lastNameTextField)) {return false;}

            //validate to make sure the user name is a valid email format
            if (!Validator.isValidUser(userTextField.getText())) {
                Validator.displayError(Validator.INVALID_EMAIL_MESSAGE);
                userTextField.requestFocus();
                return false;

            }

            //validate if the password is at least 8 characters long
            if (!Validator.isValidPassword(passwordTextField.getText())){
                Validator.displayError(Validator.INVALID_PASSWORD_MESSAGE);
                passwordTextField.requestFocus();
                return false;
            }

            //make sure the password confirmation matches the password.
            if (!confirmPasswordTextField.getText().trim().equals(passwordTextField.getText().trim())) {
                Validator.displayError(Validator.PASSWORD_NOMATCH_ERROR);
                confirmPasswordTextField.requestFocus();
                return false;
            }
            return true;
        }

    /**
     * isFieldEmpty can be used to validate text fields where the validation is simply to make sure that
     * the field was not left blank.  The function takes the textfield passed in and uses
     * Validator.fieldIfBlankError to validate that the field is not blank and if it is, this function
     * generates the required error message to the user.  The focus is automatically reset to the empty field
     * if it was found to have been left empty.
     * @param field, TextField type, the text field for which the text value must be validated to see
     *               if it has been left blank.
     * @return      boolean type, returns true if the field was left empty and false is it was not left empty.
     */
    private boolean isFieldEmpty(TextField field) {
            if (Validator.fieldIfBlankError(field)){
                field.requestFocus();
                return true;
            } else return false;
        }

        /**
         *  save() will eventually save the user signup information to a database.  However for Assignment 4
         *  the method only loops through all the children of the signupVBox which contains all the text
         *  fields to be filled in by the user.  In the loop it validates to see if each control is a TextField
         *  type.  If it is, it will print it's text value to the console.
         *  Finally, the method uses the DisplayMessage static utility class to display a message to the user
         *  that their information has been saved.
         */
        private void save() {

            //print the values from the text fields to the console.
            signupVBox.getChildren().stream().forEach((c)->{
                if ( c instanceof TextField){
                    System.out.println(((TextField)c).getText());
                }
            });

            //display a message to the user that their information was successfully saved.
            DisplayMessage.displayInformationalMessage(DisplayMessage.SAVED_TITLE,
                    DisplayMessage.SAVED_MESSAGE);
        }
}

